package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val colorHex: String = "#F3EDF7", // Default pastel lavender-grey
    val category: String = "সব", // "সব", "ব্যক্তিগত", "কাজ", "ধারণা", "অন্যান্য"
    val isPinned: Boolean = false
)
