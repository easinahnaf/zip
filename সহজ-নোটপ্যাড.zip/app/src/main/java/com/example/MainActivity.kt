package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.Note
import com.example.ui.NoteViewModel
import com.example.ui.theme.MyApplicationTheme
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        NoteApp()
      }
    }
  }
}

// Color palette definitions for individual notes (beautiful professional pastels)
val noteColors = listOf(
    "#F3EDF7", // Lavender Grey
    "#F7F2FA", // Soft Lavender
    "#FEF7FF", // Lavender White
    "#FFF9C4", // Warm Yellow
    "#E8F5E9", // Pastel Mint
    "#E3F2FD"  // Soft Blue
)

// Names for color keys to describe them visually
val colorNames = mapOf(
    "#F3EDF7" to "ধূসর ল্যাভেন্ডার",
    "#F7F2FA" to "হালকা ল্যাভেন্ডার",
    "#FEF7FF" to "সাদা ল্যাভেন্ডার",
    "#FFF9C4" to "হলুদ",
    "#E8F5E9" to "সবুজ",
    "#E3F2FD" to "নীল"
)

fun parseHexColor(hex: String): Color {
    return try {
        Color(android.graphics.Color.parseColor(hex))
    } catch (e: Exception) {
        Color(0xFFF3EDF7) // Default fallback
    }
}

fun formatTimestamp(timestamp: Long): String {
    val sdf = SimpleDateFormat("hh:mm a, dd MMM yyyy", Locale.getDefault())
    return sdf.format(Date(timestamp))
}

@Composable
fun NoteApp(
    viewModel: NoteViewModel = viewModel()
) {
    val notes by viewModel.notes.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()

    var activeTab by remember { mutableStateOf(0) }
    var editingNote by remember { mutableStateOf<Note?>(null) }
    var showDeleteConfirmDialog by remember { mutableStateOf<Note?>(null) }

    val categories = listOf("সব", "ব্যক্তিগত", "কাজ", "ধারণা", "অন্যান্য")

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.height(80.dp)
            ) {
                // Tab 0: Notes
                NavigationBarItem(
                    selected = activeTab == 0,
                    onClick = { activeTab = 0 },
                    icon = { Icon(Icons.Default.Home, contentDescription = "নোটস") },
                    label = { Text("নোটস", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        selectedTextColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
                // Tab 1: Reminders
                NavigationBarItem(
                    selected = activeTab == 1,
                    onClick = { activeTab = 1 },
                    icon = { Icon(Icons.Default.Notifications, contentDescription = "রিমাইন্ডার") },
                    label = { Text("রিমাইন্ডার", fontSize = 12.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        selectedTextColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
                // Tab 2: Archive
                NavigationBarItem(
                    selected = activeTab == 2,
                    onClick = { activeTab = 2 },
                    icon = { Icon(Icons.Default.List, contentDescription = "আর্কাইভ") },
                    label = { Text("আর্কাইভ", fontSize = 12.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        selectedTextColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
            }
        },
        floatingActionButton = {
            if (activeTab == 0) {
                FloatingActionButton(
                    onClick = {
                        editingNote = Note(
                            title = "",
                            content = "",
                            category = "ব্যক্তিগত",
                            colorHex = "#F3EDF7"
                        )
                    },
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.testTag("add_note_fab")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "নতুন নোট যোগ করুন",
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            if (activeTab == 0) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp)
                ) {
                    // Elegant Header Area
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "সহজ নোটপ্যাড",
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = if (notes.isEmpty()) "কোনো নোট সংরক্ষিত নেই" else "${notes.size}টি নোট সংরক্ষিত আছে",
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                            )
                        }
                        IconButton(
                            onClick = {
                                // Info Dialog
                            },
                            modifier = Modifier.background(MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = "App Information",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Search Bar Component in Professional M3 Style
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { viewModel.setSearchQuery(it) },
                        placeholder = { Text("আপনার নোটগুলি খুঁজুন...") },
                        leadingIcon = { 
                            Icon(
                                imageVector = Icons.Default.Menu, 
                                contentDescription = "Menu Icon",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            ) 
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear search", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            } else {
                                Box(
                                    modifier = Modifier
                                        .padding(end = 8.dp)
                                        .size(32.dp)
                                        .background(MaterialTheme.colorScheme.primary, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "S",
                                        color = Color.White,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(28.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                            focusedTextColor = MaterialTheme.colorScheme.onSurface,
                            unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("search_input")
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Bengali Category Tabs
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(categories) { category ->
                            val isSelected = selectedCategory == category
                            FilterChip(
                                selected = isSelected,
                                onClick = { viewModel.setSelectedCategory(category) },
                                label = { Text(category, fontSize = 14.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Notes Grid or Empty State
                    if (notes.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                                modifier = Modifier.padding(24.dp)
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.img_empty_notes),
                                    contentDescription = "No notes found",
                                    modifier = Modifier
                                        .size(220.dp)
                                        .clip(RoundedCornerShape(16.dp)),
                                    contentScale = ContentScale.Crop
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    text = if (searchQuery.isNotEmpty()) "কোনো মিল পাওয়া যায়নি!" else "নোট খাতা সম্পূর্ণ খালি!",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = if (searchQuery.isNotEmpty()) 
                                        "অন্য কিছু দিয়ে সার্চ করার চেষ্টা করুন অথবা ফিল্টার পরিবর্তন করুন।" 
                                    else 
                                        "আপনার প্রয়োজনীয় তথ্য বা চিন্তা লিখে রাখতে নিচের যোগ করুন বাটনে ট্যাপ করুন।",
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    } else {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(2),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                        ) {
                            items(notes, key = { it.id }) { note ->
                                NoteCard(
                                    note = note,
                                    onClick = { editingNote = note },
                                    onLongClick = { showDeleteConfirmDialog = note }
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
            } else if (activeTab == 1) {
                // Reminders Tab View
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "রিমাইন্ডার",
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(48.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(24.dp))
                    Text(
                        text = "রিমাইন্ডার খাতা",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "এখানে আপনার রিমাইন্ডারগুলো থাকবে। নির্দিষ্ট সময়ে আপনাকে অ্যালার্ট করা হবে। ফিচারটি শিগগিরই আসছে!",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        lineHeight = 20.sp
                    )
                }
            } else if (activeTab == 2) {
                // Archive Tab View
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .background(MaterialTheme.colorScheme.secondaryContainer, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.List,
                            contentDescription = "আর্কাইভ",
                            tint = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.size(48.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(24.dp))
                    Text(
                        text = "আর্কাইভ খাতা",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "এখানে আপনার আর্কাইভ করা পুরোনো বা প্রয়োজনীয় নোটগুলো সযত্নে সংরক্ষিত থাকবে। ফিচারটি শিগগিরই আসছে!",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        lineHeight = 20.sp
                    )
                }
            }

            // Sliding Editor Overlay
            AnimatedVisibility(
                visible = editingNote != null,
                enter = slideInVertically(
                    initialOffsetY = { it },
                    animationSpec = spring(stiffness = 300f)
                ) + fadeIn(),
                exit = slideOutVertically(
                    targetOffsetY = { it },
                    animationSpec = spring(stiffness = 300f)
                ) + fadeOut()
            ) {
                editingNote?.let { note ->
                    NoteEditorOverlay(
                        note = note,
                        onClose = { editingNote = null },
                        onSave = { updatedNote ->
                            if (updatedNote.id == 0) {
                                viewModel.insertNote(updatedNote)
                            } else {
                                viewModel.updateNote(updatedNote)
                            }
                            editingNote = null
                        },
                        onDelete = { noteToDelete ->
                            showDeleteConfirmDialog = noteToDelete
                        }
                    )
                }
            }

            // Delete Confirmation Dialog
            if (showDeleteConfirmDialog != null) {
                val noteToDelete = showDeleteConfirmDialog!!
                AlertDialog(
                    onDismissRequest = { showDeleteConfirmDialog = null },
                    title = { Text("নোট মুছে ফেলার সতর্কতা") },
                    text = { Text("আপনি কি নিশ্চিতভাবে '${noteToDelete.title.ifEmpty { "শিরোনামহীন নোট" }}' নোটটি মুছে ফেলতে চান?") },
                    confirmButton = {
                        TextButton(
                            onClick = {
                                viewModel.deleteNoteById(noteToDelete.id)
                                showDeleteConfirmDialog = null
                                // If the note being edited was deleted, close editor too
                                if (editingNote?.id == noteToDelete.id) {
                                    editingNote = null
                                }
                            }
                        ) {
                            Text("মুছে ফেলুন", color = MaterialTheme.colorScheme.error)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showDeleteConfirmDialog = null }) {
                            Text("বাতিল করুন")
                        }
                    }
                )
            }
        }
    }
}


@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun NoteCard(
    note: Note,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val cardColor = parseHexColor(note.colorHex)
    // Contrast color for text on the note card
    val contentColor = Color(0xFF1E293B) // Dark charcoal text is beautiful and highly readable on pastels

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = cardColor),
        border = if (note.isPinned) {
            BorderStroke(2.dp, Color(0xFFD0BCFF))
        } else {
            BorderStroke(1.dp, Color(0xFFCAC4D0))
        },
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("note_card_${note.id}")
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Category Chip Inside Note
                Box(
                    modifier = Modifier
                        .background(contentColor.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = note.category,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = contentColor.copy(alpha = 0.7f)
                    )
                }

                // Star Indicator for Pinned/Starred Notes
                if (note.isPinned) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "Starred note",
                        tint = Color(0xFFF59E0B), // Golden Star
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Note Title
            Text(
                text = note.title.ifEmpty { "শিরোনামহীন" },
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = contentColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Note Content Snippet
            Text(
                text = note.content.ifEmpty { "কোনো বর্ণনা নেই" },
                fontSize = 13.sp,
                color = contentColor.copy(alpha = 0.75f),
                maxLines = 4,
                overflow = TextOverflow.Ellipsis,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Humanized Timestamp
            Text(
                text = formatTimestamp(note.timestamp),
                fontSize = 10.sp,
                color = contentColor.copy(alpha = 0.5f),
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun NoteEditorOverlay(
    note: Note,
    onClose: () -> Unit,
    onSave: (Note) -> Unit,
    onDelete: (Note) -> Unit
) {
    var title by remember { mutableStateOf(note.title) }
    var content by remember { mutableStateOf(note.content) }
    var category by remember { mutableStateOf(note.category) }
    var colorHex by remember { mutableStateOf(note.colorHex) }
    var isPinned by remember { mutableStateOf(note.isPinned) }

    val editorBgColor = parseHexColor(colorHex)
    val contentColor = Color(0xFF1E293B) // Slate Charcoal

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.5f))
            .clickable(
                onClick = {
                    // Tap background auto-saves and closes
                    onSave(note.copy(
                        title = title,
                        content = content,
                        category = category,
                        colorHex = colorHex,
                        isPinned = isPinned,
                        timestamp = System.currentTimeMillis()
                    ))
                },
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            )
    ) {
        // Sliding editor sheet
        Card(
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
            colors = CardDefaults.cardColors(containerColor = editorBgColor),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.92f)
                .align(Alignment.BottomCenter)
                // Consume clicks inside the card to avoid auto-dismissing
                .clickable(
                    onClick = {},
                    indication = null,
                    interactionSource = remember { MutableInteractionSource() }
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Editor Action Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(
                        onClick = {
                            // Close & auto-save
                            onSave(note.copy(
                                title = title,
                                content = content,
                                category = category,
                                colorHex = colorHex,
                                isPinned = isPinned,
                                timestamp = System.currentTimeMillis()
                            ))
                        },
                        modifier = Modifier.background(contentColor.copy(alpha = 0.06f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "ফিরে যান ও সেভ করুন",
                            tint = contentColor
                        )
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Toggle Pinned/Starred status
                        IconButton(
                            onClick = { isPinned = !isPinned },
                            modifier = Modifier.background(
                                if (isPinned) Color(0xFFFEF3C7) else contentColor.copy(alpha = 0.06f),
                                CircleShape
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = if (isPinned) "Unstar" else "Star",
                                tint = if (isPinned) Color(0xFFD97706) else contentColor.copy(alpha = 0.3f)
                            )
                        }

                        // Delete button (Only show for existing saved notes)
                        if (note.id != 0) {
                            IconButton(
                                onClick = { onDelete(note) },
                                modifier = Modifier
                                    .background(Color(0xFFFEE2E2), CircleShape)
                                    .testTag("delete_note_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "নোট মুছুন",
                                    tint = Color(0xFFDC2626)
                                )
                            }
                        }

                        // Explicit Save Button
                        Button(
                            onClick = {
                                onSave(note.copy(
                                    title = title,
                                    content = content,
                                    category = category,
                                    colorHex = colorHex,
                                    isPinned = isPinned,
                                    timestamp = System.currentTimeMillis()
                                ))
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = contentColor,
                                contentColor = editorBgColor
                            ),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.testTag("save_note_button")
                        ) {
                            Text("সংরক্ষণ", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Scrollable content area for fields
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                ) {
                    // Note Title TextField
                    TextField(
                        value = title,
                        onValueChange = { title = it },
                        placeholder = { 
                            Text(
                                "শিরোনাম লিখুন...",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = contentColor.copy(alpha = 0.4f)
                            ) 
                        },
                        textStyle = LocalTextStyle.current.copy(
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = contentColor
                        ),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            disabledContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        ),
                        keyboardOptions = KeyboardOptions(
                            capitalization = KeyboardCapitalization.Sentences,
                            imeAction = ImeAction.Next
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("note_title_input")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Note Content TextField
                    TextField(
                        value = content,
                        onValueChange = { content = it },
                        placeholder = { 
                            Text(
                                "এখানে নোট লেখা শুরু করুন...",
                                fontSize = 16.sp,
                                color = contentColor.copy(alpha = 0.4f)
                            ) 
                        },
                        textStyle = LocalTextStyle.current.copy(
                            fontSize = 16.sp,
                            color = contentColor,
                            lineHeight = 24.sp
                        ),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            disabledContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        ),
                        keyboardOptions = KeyboardOptions(
                            capitalization = KeyboardCapitalization.Sentences
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 200.dp)
                            .testTag("note_content_input")
                    )
                }

                // Category Selector Section
                HorizontalDivider(color = contentColor.copy(alpha = 0.1f), modifier = Modifier.padding(vertical = 12.dp))
                
                Text(
                    text = "বিভাগ নির্বাচন করুন:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = contentColor.copy(alpha = 0.6f),
                    modifier = Modifier.padding(bottom = 6.dp)
                )

                val activeCategories = listOf("ব্যক্তিগত", "কাজ", "ধারণা", "অন্যান্য")
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(activeCategories) { cat ->
                        val isSel = category == cat
                        val chipBgColor = if (isSel) contentColor else contentColor.copy(alpha = 0.05f)
                        val chipTextColor = if (isSel) editorBgColor else contentColor

                        Box(
                            modifier = Modifier
                                .background(chipBgColor, RoundedCornerShape(12.dp))
                                .border(
                                    width = 1.dp,
                                    color = if (isSel) Color.Transparent else contentColor.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable { category = cat }
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = cat,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = chipTextColor
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Color Selection Row
                Text(
                    text = "নোটের ব্যাকগ্রাউন্ড কালার:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = contentColor.copy(alpha = 0.6f),
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    noteColors.forEach { col ->
                        val colObj = parseHexColor(col)
                        val isSel = colorHex == col
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(colObj)
                                .border(
                                    width = if (isSel) 3.dp else 1.dp,
                                    color = if (isSel) contentColor else contentColor.copy(alpha = 0.2f),
                                    shape = CircleShape
                                )
                                .clickable { colorHex = col }
                        ) {
                            if (isSel) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "Selected Color",
                                    tint = contentColor,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
